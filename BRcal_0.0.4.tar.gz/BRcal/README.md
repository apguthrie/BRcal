This repository contains the source files for the R package BRcal.  The tarball for this package as of 6:09pm June 17, 2024 can be found in BRcal_0.0.0.9000.tar.gz.  

For more information about the methodology behind this package see *Boldness-Recalibration for Binary Events* (Guthrie and Franck 2024).  https://www.tandfonline.com/doi/full/10.1080/00031305.2024.2339266?src=exp-la
